<template>
    <h1 class="text-center mt-3">About ActionList</h1>
    <hr />
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10">
                <header class="text-center mb-4">
                    <p class="lead text-muted">
                        A modern application for efficient task organization and
                        management.
                    </p>
                </header>

                <section class="mb-5">
                    <h3>Main Features</h3>
                    <ul class="list-unstyled ps-3">
                        <li class="mb-3">
                            <i
                                class="bi bi-check-circle-fill text-success me-2"></i>
                            <strong>Task Creation:</strong>
                            Quickly and easily create tasks.
                        </li>
                        <li class="mb-3">
                            <i
                                class="bi bi-check-circle-fill text-success me-2"></i>
                            <strong>Task Editing:</strong>
                            Inline editing directly on the page for faster
                            updates.
                        </li>
                        <li class="mb-3">
                            <i
                                class="bi bi-check-circle-fill text-success me-2"></i>
                            <strong>Filtering and Searching:</strong>
                            Efficiently filter tasks by status or search by ID.
                        </li>
                        <li>
                            <i
                                class="bi bi-check-circle-fill text-success me-2"></i>
                            <strong>Responsive Design:</strong>
                            Optimized for mobile and desktop devices.
                        </li>
                    </ul>
                </section>

                <section class="mb-5">
                    <h3>Technologies Used</h3>
                    <ul class="list-unstyled ps-3">
                        <li class="mb-3">
                            <i class="bi bi-code-slash text-primary me-2"></i>
                            <strong>Frontend:</strong>
                            Vue.js and Vite
                        </li>
                        <li class="mb-3">
                            <i class="bi bi-server text-primary me-2"></i>
                            <strong>Backend:</strong>
                            C#
                        </li>
                        <li class="mb-3">
                            <i
                                class="bi bi-database-fill text-primary me-2"></i>
                            <strong>Database:</strong>
                            PostgreSQL
                        </li>
                        <li>
                            <i class="bi bi-tools text-primary me-2"></i>
                            <strong>Other Tools:</strong>
                            Bootstrap, Axios
                        </li>
                    </ul>
                </section>
            </div>
        </div>
    </div>
</template>

<script setup></script>
